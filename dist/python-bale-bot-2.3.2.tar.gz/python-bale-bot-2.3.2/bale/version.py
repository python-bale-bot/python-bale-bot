__version__ = '2.3.2'
BALE_API_BASE_URL = 'https://tapi.bale.ai/'
BALE_API_FILE_URL = 'https://tapi.bale.ai/file'
BALE_API_VERSION = '1.0.0'

import sys
from .version import __version__


def main():
    print("Python-Bale-Bot By Kian Ahmadian")
    print("Python Version: ", sys.version)
    print("Package Version: ", __version__)


if __name__ == '__main__':
    main()

<div align='center'>
<h1><b> Python-Bale-Bot</b></h1>

<code>An API wrapper for Bale written in Python.</code>

[![All Contributors](https://img.shields.io/github/contributors/kian-ahmadian/python-bale-bot?style=for-the-badge)](#contributors-)
[![Stars](https://img.shields.io/github/stars/kian-ahmadian/python-bale-bot?style=for-the-badge)](#starsg-)
<a href="https://github.com/kian-ahmadian/python-bale-bot/blob/main/LICENSE"> ![License](https://img.shields.io/github/license/kian-ahmadian/python-bale-bot?style=for-the-badge) </a>
<img src='https://img.shields.io/badge/License-MIT-blue&style=for-the-badge' alt='' /> <a href=''> <img src='https://img.shields.io/badge/Testing-passing-green?logo=github&style=for-the-badge' alt='' /> </a> <img src='https://img.shields.io/badge/Python-> 3.8-red?logo=python&style=for-the-badge' alt='' />
<a href='https://pypi.org/p/python-bale-bot'><img src='https://img.shields.io/pypi/v/python-bale-bot?color=blue&label=pypi&style=for-the-badge' alt='' /> </a>
</div>

## Installing
<div align='center'>


### with PyPi:

```
pip install python-bale-bot -U
```
### with Git:

```
pip install git+https://github.com/kian-ahmadian/python-bale-bot/ -U
```
</div>

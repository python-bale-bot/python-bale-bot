import sys

def main():
    
    print("Pyhton-Bale-Bot By Kian Ahmadian")
    print("Python Version: ", sys.version)

if __name__ == '__main__':
    main()
    
    
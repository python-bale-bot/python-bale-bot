__version__ = '2.1.1'
BALE_API_VERSION =  '1.0'